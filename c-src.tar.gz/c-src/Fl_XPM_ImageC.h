#ifndef __FL_XPM_IMAGE_C__
#define __FL_XPM_IMAGE_C__
#ifdef __cplusplus
#include "FL/Fl.H"
#include "FL/Fl_XPM_Image.H"
#include "Fl_CallbackC.h"
EXPORT {
#endif
  FL_EXPORT_C_HEADER(fl_XPM_Image,Fl_XPM_Image_New,(const char* filename));
#ifdef __cplusplus
}
#endif
#endif
