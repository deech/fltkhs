#ifndef __UTILS__
#define __UTILS__
#ifdef __cplusplus
#include "Fl_Types.h"
#include "FL/Fl.H"
#include "FL/Fl_Menu_Item.H"
Fl_Menu_Item* convert(fl_Menu_Item* item, int size);
#endif
#endif
