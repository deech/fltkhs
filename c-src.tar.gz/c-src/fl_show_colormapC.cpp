#include "fl_show_colormapC.h"
#ifdef __cplusplus
EXPORT {
#endif
  FL_EXPORT_C(Fl_Color, flc_show_colormap)(Fl_Color oldcol){
    return fl_show_colormap(oldcol);
  }
#ifdef __cplusplus
}
#endif
