README for the nanosvg library bundled with FLTK
------------------------------------------------

This is a header-only library to display SVG images.

This bundled library was modified for optimal use in the FLTK library.


The original library can be found here:

  https://github.com/memononen/nanosvg


The modified library was cloned and can be found here:

  https://github.com/fltk/nanosvg


For more information see README.bundled-libs.txt in FLTK's root directory.
